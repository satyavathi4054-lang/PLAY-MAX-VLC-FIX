PLAY MAX Native VLC Inline Player

ఈ project లో WebView ఆధారిత PLAY MAX Home/Movie Details UI యథాతథంగా ఉంచబడింది. HTML player స్థానంలో అదే player-wrapper ప్రాంతంలో Android Native VLCVideoLayout overlay చూపించబడుతుంది.

Google Sheets నుండి వచ్చిన stream_url ను JavaScript bridge ద్వారా MainActivity లోని LibVLC MediaPlayer కు పంపుతుంది. Player controls లో seek, play/pause, audio track, subtitle track మరియు fullscreen ఉన్నాయి.

Build చేయడానికి Android Studio లో project open చేసి Gradle sync చేసి :app:assembleDebug నడపండి. compileSdk 36, JDK 17 అవసరం. VLC dependency: org.videolan.android:libvlc-all:3.7.0.

గమనిక: ఈ source ZIP లో Android Gradle build execute చేయబడలేదు. Android device లో HTTP/HTTPS stream, audio tracks, subtitles, fullscreen behavior తప్పనిసరిగా verify చేయాలి.
